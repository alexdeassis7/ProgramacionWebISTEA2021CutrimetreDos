import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterimages'
})
export class FilterimagesPipe implements PipeTransform {

  transform(items: any[], bike: string): any {
    if (bike === 'all') {
      return items; //si me viene el valor "all" en el parametro bike retornamos el array completo 
    } else {
      return items.filter(item => {
        return item.brand === bike;
      });
    }
  }
}