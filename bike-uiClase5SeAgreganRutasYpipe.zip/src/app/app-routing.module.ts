import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './components/about/about.component';
import { AdminComponent } from './components/admin/admin.component';
import { HomeComponent } from './components/home/home.component';
import { ImageGalleryComponent } from './components/image-gallery/image-gallery.component';
import { ImagedetailsComponent } from './components/imagedetails/imagedetails.component';
import { ViewRegistrationComponent } from './components/view-registration/view-registration.component';

//dentro del siguiente array definimos las rutas de nuestra app (module)
const routes: Routes = [
  {
    path: 'home', //localhost:4200/home
    component: HomeComponent//este sera el component a renderizar
  },
  {
    path: 'admin/view/:id', //localhost:4200/admin/view/${id}
    component: ViewRegistrationComponent//este sera el component a renderizar ,
  },
  {
    path: 'admin', //localhost:4200/home
    component: AdminComponent //este sera el component a renderizar
  },
  {
    path: 'galeria', //localhost:4200/admin
    component: ImageGalleryComponent//este sera el component a renderizar
  },
  {
    path: 'image/:id', //localhost:4200/image/${id}
    component: ImagedetailsComponent//este sera el component a renderizar
  },
  {
    path: 'aboutus', //localhost:4200/aboutus
    //utilizamos redirectTo en la definicion de la ruta .
    redirectTo: 'home'
  },
  {
    path: '**',
    component: AboutComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
