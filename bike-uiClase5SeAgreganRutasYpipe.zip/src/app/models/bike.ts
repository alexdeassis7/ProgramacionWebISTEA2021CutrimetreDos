export interface BikeImagesDetail {
    id: number;
    brand: string;
    url: string;
}