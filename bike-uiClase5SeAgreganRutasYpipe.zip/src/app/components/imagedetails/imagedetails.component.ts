import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ImagesService } from 'src/app/services/images.service';

@Component({
  selector: 'app-imagedetails',
  templateUrl: './imagedetails.component.html',
  styleUrls: ['./imagedetails.component.css']
})
export class ImagedetailsComponent implements OnInit {

  image: any;
  idRecibidaPorUrl: number;

  //inyectamos el servicio de imagenes y el activatedRoute
  constructor(private imagesService: ImagesService, private route: ActivatedRoute) {
    //capturamos el parametro "id" que recibimos
    // en la ruta y lo asignamos a un atributo de la clase 
    this.idRecibidaPorUrl = this.route.snapshot.params['id'];
    // console.log("este valor lo tomamos de la url :" + this.route.snapshot.params['id']);
  }

  ngOnInit(): void {
    this.image = this.imagesService.getImageById(this.idRecibidaPorUrl);
  }

}
