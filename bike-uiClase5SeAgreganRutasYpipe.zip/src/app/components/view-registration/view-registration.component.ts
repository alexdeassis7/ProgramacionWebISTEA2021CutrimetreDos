import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-registration',
  templateUrl: './view-registration.component.html',
  styleUrls: ['./view-registration.component.css']
})
export class ViewRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
